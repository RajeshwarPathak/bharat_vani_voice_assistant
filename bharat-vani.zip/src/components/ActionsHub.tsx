import React, { useState } from "react";
import {
  MessageCircle,
  AppWindow,
  Search,
  Camera,
  Lock,
  Volume2,
  VolumeX,
  Volume1,
  ExternalLink,
  Play,
  Terminal,
  Calculator,
  Code,
  Globe,
  Music,
  Folder,
  CheckCircle2,
  Crop,
  Monitor,
} from "lucide-react";

interface ActionsHubProps {
  onTriggerAction: (actionType: string, details: any, spokenText: string) => void;
  onLockScreen: () => void;
  onTakeScreenshot: () => void;
  onOpenSelectSearch?: () => void;
  onOpenVisionHub?: () => void;
}

export const ActionsHub: React.FC<ActionsHubProps> = ({
  onTriggerAction,
  onLockScreen,
  onTakeScreenshot,
  onOpenSelectSearch,
  onOpenVisionHub,
}) => {
  const [recipient, setRecipient] = useState("");
  const [waMessage, setWaMessage] = useState("Namaste from Bharat Vani!");
  const [searchQuery, setSearchQuery] = useState("latest ISRO space missions");

  const apps = [
    { name: "Google Chrome", icon: Globe, target: "Chrome", url: "https://www.google.com" },
    { name: "VS Code", icon: Code, target: "Visual Studio Code", protocol: "vscode://" },
    { name: "Calculator", icon: Calculator, target: "Calculator", protocol: "calculator:" },
    { name: "Spotify", icon: Music, target: "Spotify", protocol: "spotify:" },
    { name: "Terminal", icon: Terminal, target: "Windows Terminal" },
    { name: "File Explorer", icon: Folder, target: "File Explorer" },
  ];

  const handleLaunchApp = (app: (typeof apps)[0]) => {
    // Attempt system protocol or fallback
    if (app.url) {
      window.open(app.url, "_blank");
    } else if (app.protocol) {
      window.location.href = app.protocol;
    }
    onTriggerAction(
      "launch_app",
      { target: app.name, command: `subprocess.Popen("${app.name.toLowerCase()}")` },
      `Launching ${app.name} on Windows for you now.`
    );
  };

  const handleSendWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient.trim()) return;

    // Launch WhatsApp Web or Desktop protocol
    const encoded = encodeURIComponent(waMessage);
    const waUrl = `https://web.whatsapp.com/send?text=${encoded}`;
    window.open(waUrl, "_blank");

    onTriggerAction(
      "whatsapp_message",
      {
        target: recipient,
        message: waMessage,
        command: `pywhatkit.sendwhatmsg_instantly("${recipient}", "${waMessage}")`,
      },
      `Opening WhatsApp to send "${waMessage}" to ${recipient} right away.`
    );
  };

  const handleWebSearch = (engine: "Google" | "YouTube") => {
    if (!searchQuery.trim()) return;
    const encoded = encodeURIComponent(searchQuery);
    const url =
      engine === "YouTube"
        ? `https://www.youtube.com/results?search_query=${encoded}`
        : `https://www.google.com/search?q=${encoded}`;
    window.open(url, "_blank");

    onTriggerAction(
      "web_search",
      { query: searchQuery, target: engine },
      `Searching ${engine} for "${searchQuery}".`
    );
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur-md rounded-2xl border border-slate-800/80 p-4 space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <AppWindow className="w-4 h-4 text-sky-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-mono">
            Windows PC Automation Hub
          </h3>
        </div>
        <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          ActionExecutor Online
        </span>
      </div>

      {/* 1. Quick App Launcher */}
      <div>
        <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
          <span>APP LAUNCHER (WINDOWS)</span>
          <span className="text-slate-500 text-[10px]">6 Configured</span>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {apps.map((app) => {
            const Icon = app.icon;
            return (
              <button
                key={app.name}
                onClick={() => handleLaunchApp(app)}
                className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 hover:border-amber-500/40 text-slate-300 hover:text-white transition-all group cursor-pointer"
              >
                <Icon className="w-5 h-5 text-amber-400/80 group-hover:text-amber-300 mb-1 transition-transform group-hover:scale-110" />
                <span className="text-[11px] font-medium truncate max-w-full">
                  {app.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. WhatsApp Automation Module */}
      <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
        <div className="flex items-center gap-2 mb-2 text-emerald-400 font-mono text-xs font-bold">
          <MessageCircle className="w-4 h-4" />
          <span>WHATSAPP AUTOMATION</span>
        </div>
        <form onSubmit={handleSendWhatsApp} className="space-y-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="Contact Name (e.g. Rahul, Friend)"
              className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            <input
              type="text"
              value={waMessage}
              onChange={(e) => setWaMessage(e.target.value)}
              placeholder="Message to send..."
              className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Automate WhatsApp to "{recipient}"</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </form>
      </div>

      {/* 3. System Controls & Utilities */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-1">
        {/* Select & Search Screen (Alt+S) */}
        {onOpenSelectSearch && (
          <button
            onClick={onOpenSelectSearch}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-300 text-xs font-semibold transition-all cursor-pointer"
            title="Press Alt+S anywhere to crop and search"
          >
            <Crop className="w-4 h-4 text-amber-400" />
            <span>Select & Search (Alt+S)</span>
          </button>
        )}

        {/* Live Vision & Camera Hub */}
        {onOpenVisionHub && (
          <button
            onClick={onOpenVisionHub}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-emerald-300 text-xs font-semibold transition-all cursor-pointer"
          >
            <Monitor className="w-4 h-4 text-emerald-400" />
            <span>Live Screen & Camera</span>
          </button>
        )}

        {/* Screenshot Button */}
        <button
          onClick={onTakeScreenshot}
          className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-sky-500/40 text-slate-200 text-xs font-semibold transition-all cursor-pointer"
        >
          <Camera className="w-4 h-4 text-sky-400" />
          <span>Take Screenshot</span>
        </button>

        {/* Lock Screen Button */}
        <button
          onClick={onLockScreen}
          className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-red-500/40 text-slate-200 text-xs font-semibold transition-all cursor-pointer"
        >
          <Lock className="w-4 h-4 text-red-400" />
          <span>Lock (Win+L)</span>
        </button>
      </div>

      {/* 4. Web Search Bar */}
      <div className="flex gap-2">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Voice search query..."
          className="flex-1 bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
        <button
          onClick={() => handleWebSearch("Google")}
          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 font-semibold text-xs flex items-center gap-1 cursor-pointer"
        >
          <Search className="w-3.5 h-3.5" />
          <span>Google</span>
        </button>
        <button
          onClick={() => handleWebSearch("YouTube")}
          className="px-3 py-1.5 rounded-lg bg-red-950/80 hover:bg-red-900 border border-red-800/60 text-red-200 font-semibold text-xs flex items-center gap-1 cursor-pointer"
        >
          <Search className="w-3.5 h-3.5" />
          <span>YouTube</span>
        </button>
      </div>
    </div>
  );
};
