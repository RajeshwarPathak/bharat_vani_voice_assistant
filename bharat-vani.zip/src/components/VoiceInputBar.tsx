import React, { useState, useEffect, useRef } from "react";
import { Mic, MicOff, Send, Radio, Sparkles, Volume2, Languages } from "lucide-react";
import { AssistantState, LanguageMode } from "../types";

interface VoiceInputBarProps {
  onSendCommand: (text: string) => void;
  assistantState: AssistantState;
  selectedWakeWord: string;
  isContinuousListening: boolean;
  onToggleContinuousListening: () => void;
  languageMode: LanguageMode;
  onChangeLanguage: (lang: LanguageMode) => void;
}

export const VoiceInputBar: React.FC<VoiceInputBarProps> = ({
  onSendCommand,
  assistantState,
  selectedWakeWord,
  isContinuousListening,
  onToggleContinuousListening,
  languageMode,
  onChangeLanguage,
}) => {
  const [inputText, setInputText] = useState("");
  const [isPushToTalking, setIsPushToTalking] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  // Multilingual quick prompt chips (Hindi, English & Mix)
  const quickPrompts = [
    `Convert into animated icon`,
    `Select and search screen`,
    `Kal 3 baje team sync add karo`,
    `Mujhe 5 baje chai ki yaad dilana`,
    `What's on my schedule today?`,
    `Chrome kholo`,
    `Take a screenshot`,
    `Lock my PC screen`,
  ];

  // Initialize Web Speech Recognition
  useEffect(() => {
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setSpeechSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognitionClass();
      recognition.continuous = true;
      recognition.interimResults = false;
      // Use hi-IN for Hindi, en-IN for English/Hinglish
      recognition.lang = languageMode === "hi-IN" ? "hi-IN" : "en-IN";

      recognition.onresult = (event: any) => {
        const lastIndex = event.results.length - 1;
        const transcript = event.results[lastIndex][0].transcript.trim();
        console.log("🎙️ [STT Heard]:", transcript);

        const lower = transcript.toLowerCase();
        const wakeWordLower = selectedWakeWord.toLowerCase();

        if (isPushToTalking) {
          onSendCommand(transcript);
          stopPTT();
        } else if (
          isContinuousListening &&
          (lower.includes(wakeWordLower) ||
            lower.includes("hey vani") ||
            lower.includes("ok vani") ||
            lower.includes("namaste vani") ||
            lower.includes("suno vani") ||
            lower.includes("नमस्ते वानी") ||
            lower.includes("वानी") ||
            lower.includes("vani"))
        ) {
          onSendCommand(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        if (event.error === "not-allowed") {
          setIsPushToTalking(false);
        }
      };

      recognition.onend = () => {
        // If continuous listening is enabled, auto-restart
        if (isContinuousListening) {
          try {
            recognition.start();
          } catch {
            // Ignore
          }
        } else {
          setIsPushToTalking(false);
        }
      };

      recognitionRef.current = recognition;

      if (isContinuousListening) {
        try {
          recognition.start();
        } catch {
          // Ignore
        }
      }
    } catch (e) {
      console.error("Failed to init SpeechRecognition:", e);
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // Ignore
        }
      }
    };
  }, [isContinuousListening, selectedWakeWord, languageMode]);

  const startPTT = () => {
    if (!speechSupported) {
      alert("Speech recognition is not supported in this browser. Please use the text input below.");
      return;
    }

    setIsPushToTalking(true);
    try {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        setTimeout(() => {
          try {
            recognitionRef.current.lang = languageMode === "hi-IN" ? "hi-IN" : "en-IN";
            recognitionRef.current.start();
          } catch {
            // Ignore
          }
        }, 150);
      }
    } catch {
      // Ignore
    }
  };

  const stopPTT = () => {
    setIsPushToTalking(false);
    if (!isContinuousListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendCommand(inputText.trim());
    setInputText("");
  };

  const handleChipClick = (prompt: string) => {
    onSendCommand(prompt);
  };

  const getPlaceholderText = () => {
    switch (languageMode) {
      case "hi-IN":
        return `बोलें "${selectedWakeWord}..." या लिखें (उदा. "कल 3 बजे मीटिंग जोड़ो")...`;
      case "mix":
        return `Speak "${selectedWakeWord}..." (Hinglish/English e.g. "Kal 3 baje sync add karo")...`;
      case "en-IN":
        return `Speak "${selectedWakeWord}..." (e.g. "Add dentist tomorrow at 4 PM")...`;
    }
  };

  return (
    <div className="w-full space-y-2.5">
      {/* Quick Prompt Chips (Hindi, Hinglish, English) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px] font-medium text-slate-400">
        <span className="shrink-0 text-slate-500 font-mono text-[10px] uppercase">
          Try saying:
        </span>
        {quickPrompts.map((p) => (
          <button
            key={p}
            onClick={() => handleChipClick(p)}
            className="shrink-0 px-2.5 py-1 rounded-full bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-amber-500/40 text-slate-300 hover:text-amber-300 transition-all font-mono cursor-pointer"
          >
            "{p}"
          </button>
        ))}
      </div>

      {/* Main Input Control Bar */}
      <form
        onSubmit={handleFormSubmit}
        className="relative flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 backdrop-blur-xl shadow-2xl focus-within:border-amber-500/60 transition-colors"
      >
        {/* Continuous Wake Word Listener Button */}
        <button
          type="button"
          onClick={onToggleContinuousListening}
          className={`px-3 py-2 rounded-xl text-xs font-mono font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
            isContinuousListening
              ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/10"
              : "bg-slate-800/60 text-slate-400 border border-slate-700/60 hover:text-slate-200"
          }`}
          title={
            isContinuousListening
              ? "24/7 Wake Word Listening is ACTIVE"
              : "Click to enable 24/7 Wake Word Listening"
          }
        >
          <Radio
            className={`w-3.5 h-3.5 ${
              isContinuousListening ? "text-amber-400 animate-pulse" : "text-slate-400"
            }`}
          />
          <span className="hidden sm:inline">Wake Word</span>
          <span
            className={`w-2 h-2 rounded-full ${
              isContinuousListening ? "bg-amber-400 animate-ping" : "bg-slate-600"
            }`}
          ></span>
        </button>

        {/* Language Switcher Dropdown Button */}
        <div className="flex items-center bg-slate-800/80 rounded-xl px-2 py-1.5 border border-slate-700/60 gap-1.5">
          <Languages className="w-3.5 h-3.5 text-amber-400" />
          <select
            value={languageMode}
            onChange={(e) => onChangeLanguage(e.target.value as LanguageMode)}
            className="bg-transparent text-[11px] font-mono text-slate-200 focus:outline-none cursor-pointer"
            title="Switch spoken language"
          >
            <option value="mix" className="bg-slate-900 text-slate-100">
              Mix (Hinglish)
            </option>
            <option value="hi-IN" className="bg-slate-900 text-slate-100">
              हिन्दी (hi-IN)
            </option>
            <option value="en-IN" className="bg-slate-900 text-slate-100">
              English (en-IN)
            </option>
          </select>
        </div>

        {/* Text Input */}
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={getPlaceholderText()}
          className="flex-1 bg-transparent px-2 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
        />

        {/* Push-to-Talk (PTT) Mic Button */}
        <button
          type="button"
          onMouseDown={startPTT}
          onMouseUp={stopPTT}
          onTouchStart={startPTT}
          onTouchEnd={stopPTT}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer select-none ${
            isPushToTalking
              ? "bg-red-600 text-white shadow-lg shadow-red-600/30 scale-105 animate-pulse"
              : "bg-amber-500 hover:bg-amber-400 text-slate-950 font-mono shadow-md shadow-amber-500/20"
          }`}
          title="Press & hold to speak (or click to talk)"
        >
          <Mic className="w-4 h-4" />
          <span className="hidden md:inline">
            {isPushToTalking ? "Listening..." : "Hold to Talk"}
          </span>
        </button>

        {/* Submit button for text */}
        <button
          type="submit"
          disabled={!inputText.trim()}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 transition-colors cursor-pointer"
          title="Send command"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
