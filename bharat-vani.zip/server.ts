import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Initialize server-side Gemini client using the recommended SDK
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// System status endpoint
app.get("/api/system/status", (req, res) => {
  res.json({
    status: "online",
    os: "Windows 11 Pro 64-bit (Build 22631)",
    pcName: "BHARAT-DESKTOP",
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    defaultWakeWord: "Hey Vani",
    supportedWakeWords: ["Hey Vani", "Ok Vani", "Namaste Vani"],
    voiceLocale: "en-IN",
    location: "India (IST, UTC+5:30)",
  });
});

// Process Voice or Text Command
app.post("/api/assistant/process", async (req, res) => {
  try {
    const {
      prompt,
      conversationHistory = [],
      brainMode = "gemini",
      localOllamaModel = "llama3:8b",
      languagePreference = "mix",
      userProfile,
      todayEvents = [],
      activeReminders = [],
    } = req.body;

    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Missing prompt" });
    }

    const trimmed = prompt.trim();
    const cleanPrompt = trimmed
      .replace(/^(hey vani|ok vani|namaste vani|suno vani|vani)[,\s]*/i, "")
      .trim();
    const lowerPrompt = cleanPrompt.toLowerCase();

    // 1. Check Custom Commands from active User Profile first
    if (userProfile && Array.isArray(userProfile.customCommands)) {
      for (const cmd of userProfile.customCommands) {
        if (
          cmd.phrase &&
          lowerPrompt.includes(cmd.phrase.toLowerCase())
        ) {
          return res.json({
            isAction: true,
            actionType: cmd.actionType || "custom_command",
            actionDetails: cmd.actionDetails || {},
            spokenResponse:
              cmd.spokenResponse ||
              `Executing your custom command: "${cmd.phrase}".`,
            displayText: `✨ **Custom Command Triggered**: *"${cmd.phrase}"*\n- Profile: **${userProfile.name}**\n- Action: ${cmd.actionType}`,
            engine: "user-custom-shortcut",
          });
        }
      }
    }

    // 2. Check if user requested Offline Ollama mode or Gemini online
    if (brainMode === "ollama") {
      // Offline local brain simulation / fallback
      const offlineResult = handleOfflineBrain(
        cleanPrompt || trimmed,
        localOllamaModel,
        languagePreference,
        userProfile,
        todayEvents,
        activeReminders
      );
      return res.json(offlineResult);
    }

    // 3. Server-side Gemini processing
    try {
      const ai = getGeminiClient();

      const userName = userProfile?.name || "Boss";
      const userCity = userProfile?.city || "India";

      const systemInstruction = `You are "Bharat Vani" (Voice of India 🇮🇳), a real AI voice assistant for Windows running directly on the user's PC.
Your user is: ${userName} located in ${userCity}.
Language Preference: ${languagePreference} (en-IN: Indian English, hi-IN: Pure Hindi, mix: Hinglish / colloquial Hindi-English).

Current context:
- Today's date/time: Local Indian Time (Asia/Kolkata).
- Today's active calendar events: ${JSON.stringify(todayEvents || [])}
- Active reminders: ${JSON.stringify(activeReminders || [])}

Language Rules:
- If languagePreference is "hi-IN" or user asks in Hindi: Respond in respectful, natural Hindi (Devanagari or Romanized), e.g. "नमस्ते ${userName}! कल 3 बजे मीटिंग जोड़ दी गई है।"
- If languagePreference is "mix" or user asks in Hinglish (e.g. "Kal 4 baje meeting add karo", "Mujhe 5 baje yaad dilana"): Respond in friendly, natural Hinglish, e.g. "Sure ${userName}! Kal 4 baje meeting schedule kar di hai."
- If languagePreference is "en-IN": Respond in crisp, polite Indian English, e.g. "Adding that meeting to your Windows Calendar for tomorrow at 4 PM, ${userName}."

Analyze user intent into one of these action types:
1. "add_calendar_event": User wants to schedule or add an event/meeting/appointment. (e.g. "Kal 3 baje team meeting add karo", "Schedule dentist tomorrow at 5 PM", "Meeting with client at 4 PM"). Extract eventTitle, eventDate (YYYY-MM-DD or relative 'tomorrow'/'today'), eventTime (HH:mm), and durationMinutes.
2. "check_schedule": User asks about schedule, plans, calendar, or upcoming meetings (e.g. "What is on my schedule today?", "Aaj mere kya plans hain?", "Show my meetings").
3. "set_reminder": User wants to set a reminder/alarm (e.g. "Remind me to call Rahul in 10 minutes", "Mujhe 5 baje chai ki yaad dilana", "Remind me to take medicine at 8 PM"). Extract reminderText, reminderTime (HH:mm or relative like 'in 10 minutes'), and reminderDate.
4. "check_reminders": User asks about reminders or alarms (e.g. "Any reminders for today?", "Mere reminders batao").
5. "whatsapp_message": User wants to send WhatsApp message (e.g. "Send message to Rahul on WhatsApp", "WhatsApp Priya that I reached"). Extract recipient name and message text.
6. "launch_app": User wants to open/launch an app (e.g. Chrome, VS Code, Notepad, Calculator, Spotify, Terminal, File Explorer, YouTube, or Hindi: "Chrome kholo").
7. "web_search": User wants to search Google or YouTube (e.g. "Search Google for latest tech news", "Search YouTube for A.R. Rahman songs").
8. "system_control": PC system controls like volume up, volume down, mute, battery check, CPU/RAM check.
9. "screenshot": User wants to capture a screenshot ("Take a screenshot", "Screenshot lo").
10. "lock_screen": User wants to lock the computer ("Lock my PC", "Lock screen", "PC lock karo").
11. "chat": General questions, conversational greetings, programming help, weather, calculations, jokes, general knowledge.

Respond in strict JSON with the following schema:
- isAction: boolean
- actionType: "add_calendar_event" | "check_schedule" | "set_reminder" | "check_reminders" | "whatsapp_message" | "launch_app" | "web_search" | "system_control" | "screenshot" | "lock_screen" | "chat"
- actionDetails: {
    target?: string,
    message?: string,
    query?: string,
    command?: string,
    eventTitle?: string,
    eventDate?: string,
    eventTime?: string,
    durationMinutes?: number,
    reminderText?: string,
    reminderTime?: string,
    reminderDate?: string
  }
- spokenResponse: Short, natural voice response (1-2 sentences max, respectful, matching language tone).
- displayText: Clear, markdown-friendly text for the HUD chat log.
- engine: "gemini-3.8-flash"`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: cleanPrompt || trimmed,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              isAction: { type: Type.BOOLEAN },
              actionType: {
                type: Type.STRING,
                description:
                  "add_calendar_event, check_schedule, set_reminder, check_reminders, launch_app, whatsapp_message, web_search, system_control, screenshot, lock_screen, or chat",
              },
              actionDetails: {
                type: Type.OBJECT,
                properties: {
                  target: { type: Type.STRING },
                  message: { type: Type.STRING },
                  query: { type: Type.STRING },
                  command: { type: Type.STRING },
                  eventTitle: { type: Type.STRING },
                  eventDate: { type: Type.STRING },
                  eventTime: { type: Type.STRING },
                  durationMinutes: { type: Type.NUMBER },
                  reminderText: { type: Type.STRING },
                  reminderTime: { type: Type.STRING },
                  reminderDate: { type: Type.STRING },
                },
              },
              spokenResponse: { type: Type.STRING },
              displayText: { type: Type.STRING },
              engine: { type: Type.STRING },
            },
            required: ["isAction", "actionType", "spokenResponse", "displayText"],
          },
        },
      });

      const raw = response.text || "{}";
      const parsed = JSON.parse(raw);
      parsed.engine = "gemini-3.8-flash";
      return res.json(parsed);
    } catch (geminiError) {
      console.warn(
        "Gemini API call failed, automatically failing over to offline Ollama fallback:",
        geminiError
      );
      // Automatic failover to local offline fallback as per Bharat Vani offline design
      const fallback = handleOfflineBrain(
        cleanPrompt || trimmed,
        "ollama-auto-failover",
        languagePreference,
        userProfile,
        todayEvents,
        activeReminders
      );
      fallback.note =
        "Automatically switched to Offline Fallback Mode (Internet/API failover)";
      return res.json(fallback);
    }
  } catch (error: any) {
    console.error("Assistant process error:", error);
    res.status(500).json({
      error: error.message || "Failed to process voice command",
      spokenResponse:
        "I encountered an issue processing that command. Please try again.",
      displayText: "Error processing command. Switching to standby.",
      isAction: false,
      actionType: "chat",
      engine: "fallback",
    });
  }
});

// Offline Ollama / Rule-based Brain Router
interface OfflineBrainResult {
  isAction: boolean;
  actionType: string;
  actionDetails?: {
    target?: string;
    message?: string;
    query?: string;
    command?: string;
    eventTitle?: string;
    eventDate?: string;
    eventTime?: string;
    reminderText?: string;
    reminderTime?: string;
    reminderDate?: string;
  };
  spokenResponse: string;
  displayText: string;
  engine: string;
  note?: string;
}

function handleOfflineBrain(
  prompt: string,
  engineName = "ollama-local",
  languagePreference = "mix",
  userProfile?: any,
  todayEvents: any[] = [],
  activeReminders: any[] = []
): OfflineBrainResult {
  const p = prompt.toLowerCase();
  const userName = userProfile?.name || "Boss";
  const isHindi = languagePreference === "hi-IN" || /[\u0900-\u097F]/.test(prompt);

  // 1. Calendar: Add Event or Meeting
  if (
    p.includes("add event") ||
    p.includes("schedule") ||
    p.includes("meeting") ||
    p.includes("appointment") ||
    p.includes("calendar me add") ||
    p.includes("meeting add karo")
  ) {
    let title = "Meeting";
    let time = "15:00";
    let date = "today";

    if (p.includes("tomorrow") || p.includes("kal")) date = "tomorrow";
    const timeMatch = p.match(/(\d{1,2})\s*(?:baje|am|pm|:00)?/i);
    if (timeMatch) {
      let hr = parseInt(timeMatch[1], 10);
      if ((p.includes("shaam") || p.includes("pm") || p.includes("afternoon")) && hr < 12) {
        hr += 12;
      }
      time = `${String(hr).padStart(2, "0")}:00`;
    }

    const titleExtract = prompt.replace(/(schedule|add|meeting|appointment|tomorrow|kal|today|at|baje|on|calendar|in|karo)/gi, "").trim();
    if (titleExtract.length > 2) title = titleExtract;

    return {
      isAction: true,
      actionType: "add_calendar_event",
      actionDetails: {
        eventTitle: title,
        eventDate: date,
        eventTime: time,
      },
      spokenResponse: isHindi
        ? `जी ${userName}, ${date === "tomorrow" ? "कल" : "आज"} ${time} पर "${title}" का इवेंट कैलेंडर में जोड़ दिया है।`
        : `Scheduled "${title}" for ${date} at ${time} in your calendar.`,
      displayText: `📅 **Calendar Event Added**:\n- **Title**: ${title}\n- **Date**: ${date}\n- **Time**: ${time}\n- *Synced to Windows Calendar (.ics ready)*`,
      engine: engineName,
    };
  }

  // 2. Calendar: Check Schedule
  if (
    p.includes("schedule") ||
    p.includes("plans") ||
    p.includes("calendar") ||
    p.includes("aaj kya hai") ||
    p.includes("mere plans")
  ) {
    const count = todayEvents.length;
    return {
      isAction: true,
      actionType: "check_schedule",
      spokenResponse: isHindi
        ? `आपके आज के शेड्यूल में ${count} इवेंट्स हैं।`
        : `You have ${count} events scheduled for today, ${userName}.`,
      displayText: `📅 **Today's Schedule**: Found ${count} events on your Windows Calendar.`,
      engine: engineName,
    };
  }

  // 3. Reminders: Set Reminder
  if (
    p.includes("remind") ||
    p.includes("reminder") ||
    p.includes("yaad dilana") ||
    p.includes("yaad dila do")
  ) {
    let reminderText = "Reminder Alert";
    let reminderTime = "17:00";
    let reminderDate = "today";

    if (p.includes("tomorrow") || p.includes("kal")) reminderDate = "tomorrow";
    const timeMatch = p.match(/(\d{1,2})\s*(?:baje|am|pm|:00)?/i);
    if (timeMatch) {
      let hr = parseInt(timeMatch[1], 10);
      if ((p.includes("shaam") || p.includes("pm")) && hr < 12) hr += 12;
      reminderTime = `${String(hr).padStart(2, "0")}:00`;
    }

    const cleanReminder = prompt.replace(/(remind me to|reminder for|yaad dilana|ki yaad dila do|mujhe|baje|kal|today|shaam|subah)/gi, "").trim();
    if (cleanReminder.length > 2) reminderText = cleanReminder;

    return {
      isAction: true,
      actionType: "set_reminder",
      actionDetails: {
        reminderText,
        reminderTime,
        reminderDate,
      },
      spokenResponse: isHindi
        ? `जी, आपको ${reminderTime} पर "${reminderText}" की याद दिला दूंगी।`
        : `I have set a reminder for "${reminderText}" at ${reminderTime}.`,
      displayText: `⏰ **Voice Reminder Set**:\n- **Task**: ${reminderText}\n- **Time**: ${reminderTime} (${reminderDate})\n- *Alert Chime & TTS notification activated*`,
      engine: engineName,
    };
  }

  // 4. Reminders: Check Reminders
  if (p.includes("check reminder") || p.includes("reminders") || p.includes("yaad")) {
    const pendingCount = activeReminders.filter((r) => r.status === "pending").length;
    return {
      isAction: true,
      actionType: "check_reminders",
      spokenResponse: isHindi
        ? `आपके पास ${pendingCount} पेंडिंग रिमाइंडर्स हैं।`
        : `You have ${pendingCount} active reminders pending, ${userName}.`,
      displayText: `⏰ **Active Reminders**: ${pendingCount} pending alarms scheduled.`,
      engine: engineName,
    };
  }

  // 5. WhatsApp
  if (
    p.includes("whatsapp") ||
    (p.includes("send") && p.includes("to")) ||
    p.includes("message bhejo") ||
    p.includes("whatsapp karo")
  ) {
    let recipient = "Contact";
    let message = "Hi";

    const match = prompt.match(/(?:send|whatsapp)\s+(.*?)\s+to\s+([a-zA-Z\s]+)(?:\s+on\s+whatsapp)?/i);
    const match2 = prompt.match(/(?:send\s+whatsapp\s+message\s+to\s+|to\s+)([a-zA-Z\s]+?)(?:\s+saying\s+|\s+that\s+|\s*:\s*)(.+)/i);

    if (match) {
      message = match[1].trim();
      recipient = match[2].trim();
    } else if (match2) {
      recipient = match2[1].trim();
      message = match2[2].trim();
    }

    return {
      isAction: true,
      actionType: "whatsapp_message",
      actionDetails: {
        target: recipient,
        message: message,
        command: `pywhatkit.sendwhatmsg_instantly("${recipient}", "${message}")`,
      },
      spokenResponse: isHindi
        ? `व्हाट्सएप खोलकर ${recipient} को "${message}" संदेश भेजा जा रहा है।`
        : `Opening WhatsApp and sending "${message}" to ${recipient} now.`,
      displayText: `📱 **WhatsApp Automation**: Preparing to send message.\n- **Recipient**: ${recipient}\n- **Message**: "${message}"\n- *Executed via ActionExecutor (Local Mode)*`,
      engine: engineName,
    };
  }

  // 6. App Launcher (English & Hindi "kholo", "chalao")
  if (
    p.includes("open") ||
    p.includes("launch") ||
    p.includes("start") ||
    p.includes("kholo") ||
    p.includes("chalao")
  ) {
    let app = "Chrome";
    if (p.includes("chrome") || p.includes("browser")) app = "Google Chrome";
    else if (p.includes("vs code") || p.includes("code") || p.includes("visual studio")) app = "Visual Studio Code";
    else if (p.includes("notepad") || p.includes("editor")) app = "Notepad";
    else if (p.includes("calculator") || p.includes("calc")) app = "Calculator";
    else if (p.includes("spotify") || p.includes("music") || p.includes("gaana")) app = "Spotify";
    else if (p.includes("terminal") || p.includes("cmd") || p.includes("powershell")) app = "Windows Terminal";
    else if (p.includes("file explorer") || p.includes("files") || p.includes("folder")) app = "File Explorer";
    else if (p.includes("youtube")) app = "YouTube";

    return {
      isAction: true,
      actionType: "launch_app",
      actionDetails: {
        target: app,
        command: `subprocess.Popen("${app.toLowerCase()}")`,
      },
      spokenResponse: isHindi
        ? `आपके लिए ${app} खोला जा रहा है।`
        : `Opening ${app} for you now.`,
      displayText: `⚡ **App Launcher**: Successfully launched **${app}** on Windows.`,
      engine: engineName,
    };
  }

  // 7. Screenshot
  if (
    p.includes("screenshot") ||
    p.includes("screen capture") ||
    p.includes("snapshot") ||
    p.includes("photo lo")
  ) {
    return {
      isAction: true,
      actionType: "screenshot",
      actionDetails: {
        target: "Screen",
        command: "pyautogui.screenshot('screenshot.png')",
      },
      spokenResponse: isHindi
        ? "आपकी स्क्रीन का स्क्रीनशॉट ले लिया गया है।"
        : "Capturing your screen now, Sir.",
      displayText: `📸 **Screenshot Captured**: Saved to Windows Pictures directory.`,
      engine: engineName,
    };
  }

  // 8. Lock screen (English & Hindi "lock karo", "band karo")
  if (
    (p.includes("lock") && (p.includes("screen") || p.includes("pc") || p.includes("computer"))) ||
    p.includes("lock karo") ||
    p.includes("pc band karo")
  ) {
    return {
      isAction: true,
      actionType: "lock_screen",
      actionDetails: {
        target: "Windows Lock",
        command: "ctypes.windll.user32.LockWorkStation()",
      },
      spokenResponse: isHindi
        ? "विंडोज पीसी लॉक किया जा रहा है।"
        : "Locking your Windows PC right away.",
      displayText: `🔒 **System Control**: Windows Workstation Locked.`,
      engine: engineName,
    };
  }

  // 9. System controls (Volume, Battery, CPU)
  if (p.includes("volume") || p.includes("mute") || p.includes("sound") || p.includes("awaaz")) {
    const isUp = p.includes("up") || p.includes("increase") || p.includes("badhao");
    const isDown = p.includes("down") || p.includes("decrease") || p.includes("kam karo");
    const isMute = p.includes("mute") || p.includes("chup");

    const target = isMute ? "mute" : isUp ? "volume_up" : isDown ? "volume_down" : "volume_check";
    return {
      isAction: true,
      actionType: "system_control",
      actionDetails: {
        target,
        command: "nircmd.exe changesysvolume",
      },
      spokenResponse: isHindi
        ? isMute ? "आवाज म्यूट कर दी गई है।" : isUp ? "आवाज बढ़ा दी गई है।" : "आवाज कम कर दी गई है।"
        : isMute ? "Audio muted." : isUp ? "Increasing volume." : "Decreasing volume.",
      displayText: `🔊 **Audio Telemetry**: System volume adjusted (${target}).`,
      engine: engineName,
    };
  }

  // 10. Web search
  if (p.includes("search") || p.includes("google") || p.includes("find") || p.includes("khojo")) {
    const cleanQuery = prompt.replace(/(search for|search|google|on youtube|on google|khojo)/gi, "").trim();
    return {
      isAction: true,
      actionType: "web_search",
      actionDetails: {
        query: cleanQuery || prompt,
        target: p.includes("youtube") ? "YouTube" : "Google",
        command: `webbrowser.open("https://www.google.com/search?q=${encodeURIComponent(cleanQuery || prompt)}")`,
      },
      spokenResponse: isHindi
        ? `"${cleanQuery || prompt}" खोजा जा रहा है।`
        : `Searching ${p.includes("youtube") ? "YouTube" : "Google"} for "${cleanQuery || prompt}".`,
      displayText: `🔍 **Web Search**: Query dispatched to ${p.includes("youtube") ? "YouTube" : "Google"}: *"${cleanQuery || prompt}"*`,
      engine: engineName,
    };
  }

  // 11. Greetings / General (Hindi & English)
  if (
    p.includes("namaste") ||
    p.includes("hello") ||
    p.includes("hey") ||
    p.includes("kaise ho") ||
    p.includes("kya haal hai")
  ) {
    return {
      isAction: false,
      actionType: "chat",
      spokenResponse: isHindi
        ? `नमस्ते ${userName}! मैं भारत वानी हूँ। मैं आपके लिए क्या कर सकती हूँ?`
        : `Namaste ${userName}! I am Bharat Vani, your personal Windows AI assistant. How may I assist you today?`,
      displayText: `🇮🇳 **Namaste ${userName}!** I am **Bharat Vani**, your offline-ready AI voice assistant for Windows. I speak Hindi and English, manage your calendar and reminders, and execute PC automation.`,
      engine: engineName,
    };
  }

  if (p.includes("who are you") || p.includes("your name") || p.includes("kaun ho")) {
    return {
      isAction: false,
      actionType: "chat",
      spokenResponse: isHindi
        ? "मैं भारत वानी हूँ, विंडोज के लिए आपकी अपनी भारतीय एआई वॉइस असिस्टेंट।"
        : "I am Bharat Vani, your personal voice assistant for Windows, built specifically for India with full voice and PC automation.",
      displayText: `🤖 **About Bharat Vani**:\nI am your custom AI voice assistant for Windows. I listen for **'Hey Vani'**, transcribe Indian English, Hindi, and Hinglish, execute native Windows commands, automate WhatsApp, manage calendar and reminders, and operate seamlessly both online (Gemini) and offline (Ollama).`,
      engine: engineName,
    };
  }

  // Default question answer
  return {
    isAction: false,
    actionType: "chat",
    spokenResponse: isHindi
      ? `मैंने सुना: ${prompt}। ऑफलाइन मोड सक्रिय है। आप क्या करना चाहेंगे?`
      : `I heard: ${prompt}. Operating in local offline mode. How can I help you control your PC, manage your calendar, or answer questions?`,
    displayText: `💡 **Bharat Vani Offline Intelligence**:\nProcessed query: *"${prompt}"* via local Ollama engine. Try commanding me: *"Kal 3 baje meeting add karo"*, *"Remind me to drink water"*, *"Open Chrome"*, or *"Take a screenshot"*!`,
    engine: engineName,
  };
}

// Vision AI: Live Screen & Camera Region Selection & Search
app.post("/api/vision/analyze", async (req, res) => {
  try {
    const {
      image,
      prompt,
      mode = "search",
      source = "screen",
      languagePreference = "mix",
      cropArea,
      userName = "User",
    } = req.body;

    if (!image || typeof image !== "string") {
      return res.status(400).json({ error: "Missing image data" });
    }

    // Parse data URL
    let mimeType = "image/png";
    let base64Data = image;
    const match = image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      base64Data = match[2];
    }

    try {
      const ai = getGeminiClient();

      let systemInstruction = `You are Bharat Vani Vision AI, an intelligent screen and camera visual search assistant for Windows.
The user is ${userName}.
Current Language Preference: ${languagePreference} (Hinglish/Hindi/English).
You are analyzing a visual capture from the user's ${source === "camera" ? "live camera" : "active computer screen"}.
${cropArea ? `The user specifically selected a focused region (${cropArea.width}x${cropArea.height} px).` : "Full frame capture."}

Objectives:
1. Provide a comprehensive, accurate visual analysis.
2. If text, code, errors, or formulas are visible, transcribe or fix them.
3. If products, brands, movies, UI elements, or landmarks are visible, identify them and provide context.
4. Keep the tone helpful, professional, and clear.`;

      let queryText = prompt || "Analyze this image and explain what is visible.";
      if (mode === "ocr") {
        queryText = prompt
          ? `${prompt}\nExtract all readable text, code, and labels from this image with exact precision.`
          : "Extract and transcribe all text, code snippets, logs, URLs, and labels from this image. Keep formatting intact with markdown code blocks.";
      } else if (mode === "explain") {
        queryText = prompt
          ? `${prompt}\nExplain this in detail, diagnosing any issues, errors, or key concepts.`
          : "Explain what is shown here in detail. If it is code or an error message, explain the root cause and provide the exact solution.";
      } else if (mode === "search") {
        queryText = prompt
          ? `${prompt}\nPerform a visual search and find relevant web information, articles, or resources.`
          : "Identify what is in this selected screen area and find the latest relevant information, references, solutions, or documentation using Google Search.";
      }

      const imagePart = {
        inlineData: {
          mimeType,
          data: base64Data,
        },
      };

      const textPart = {
        text: queryText,
      };

      const config: any = {
        systemInstruction,
      };

      // Enable Google Search grounding for search mode
      if (mode === "search") {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: { parts: [imagePart, textPart] },
        config,
      });

      const fullText = response.text || "Analysis complete.";

      // Extract search grounding sources if available
      const groundingSources: Array<{ title: string; url: string }> = [];
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (Array.isArray(chunks)) {
        for (const chunk of chunks) {
          if (chunk.web?.uri) {
            groundingSources.push({
              title: chunk.web.title || chunk.web.uri,
              url: chunk.web.uri,
            });
          }
        }
      }

      // Generate a short spoken summary
      let spokenResponse = "";
      if (mode === "ocr") {
        spokenResponse = "I have extracted the text and code from your selected area.";
      } else if (mode === "search") {
        spokenResponse = "I analyzed your screen selection and found relevant Google Search results.";
      } else {
        spokenResponse = fullText.slice(0, 160).replace(/[#*`_]/g, "").trim() + "...";
      }

      return res.json({
        success: true,
        displayText: fullText,
        spokenResponse,
        groundingSources,
        mode,
        source,
        engine: "gemini-3.8-flash",
      });
    } catch (apiError: any) {
      console.warn("Gemini Vision call failed, switching to local offline analysis:", apiError?.message);

      return res.json({
        success: true,
        displayText: `🔍 **Visual Region Inspection (${source.toUpperCase()})**\n\n- **Target**: Selected region on ${source}\n- **Mode**: ${mode.toUpperCase()}\n- **Status**: Captured snapshot (${base64Data.length > 500 ? "High Resolution" : "Standard"})\n\n💡 *Offline Analysis:* The image region has been captured into your workspace. When online with Gemini API, full real-time visual grounding and OCR will automatically run.`,
        spokenResponse: `Captured your ${source} selection for ${mode}.`,
        groundingSources: [],
        mode,
        source,
        engine: "offline-vision-inspector",
      });
    }
  } catch (err: any) {
    console.error("Vision endpoint error:", err);
    return res.status(500).json({ error: err.message || "Failed to process visual capture" });
  }
});

// Grounded Query Endpoint (Google Search & Google Maps Grounding)
app.post("/api/gemini/grounded-query", async (req, res) => {
  try {
    const { query, type = "search", latLng, userName = "User" } = req.body;
    if (!query || typeof query !== "string") {
      return res.status(400).json({ error: "Missing query" });
    }

    const ai = getGeminiClient();
    const config: any = {};

    if (type === "maps") {
      config.tools = [{ googleMaps: {} }];
      if (latLng && typeof latLng.latitude === "number" && typeof latLng.longitude === "number") {
        config.toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: latLng.latitude,
              longitude: latLng.longitude,
            },
          },
        };
      }
    } else {
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: query,
      config,
    });

    const sources: Array<{ title: string; url: string; type: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (Array.isArray(chunks)) {
      for (const chunk of chunks) {
        if (chunk.web?.uri) {
          sources.push({
            title: chunk.web.title || chunk.web.uri,
            url: chunk.web.uri,
            type: "web",
          });
        }
        if (chunk.maps?.uri) {
          sources.push({
            title: chunk.maps.title || "View on Google Maps",
            url: chunk.maps.uri,
            type: "maps",
          });
        }
      }
    }

    return res.json({
      success: true,
      text: response.text || "",
      sources,
      engine: "gemini-3.8-flash",
      type,
    });
  } catch (err: any) {
    console.error("Grounded query error:", err);
    return res.status(500).json({ error: err.message || "Failed to execute grounded query" });
  }
});

// Audio Transcription Endpoint (using gemini-3.5-transcribe)
app.post("/api/gemini/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType = "audio/webm" } = req.body;
    if (!audioBase64 || typeof audioBase64 !== "string") {
      return res.status(400).json({ error: "Missing audioBase64 data" });
    }

    const ai = getGeminiClient();
    const audioPart = {
      inlineData: {
        mimeType,
        data: audioBase64.replace(/^data:[^;]+;base64,/, ""),
      },
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-transcribe",
      contents: {
        parts: [
          audioPart,
          {
            text: "Transcribe this audio accurately. Capture the exact spoken words in Hindi, Indian English, or Hinglish without adding editorial commentary.",
          },
        ],
      },
    });

    return res.json({
      success: true,
      transcription: response.text || "",
      engine: "gemini-3.5-transcribe",
    });
  } catch (err: any) {
    console.error("Transcription error:", err);
    return res.status(500).json({ error: err.message || "Failed to transcribe audio" });
  }
});

// Windows Auto-Start Configuration State (In-Memory default, synced to client)
let autoStartConfig = {
  enabled: true,
  startMinimizedToIcon: false,
  playGreetingOnBoot: true,
  launchPath: "https://ais-dev-4ju56hikevwqvc657qlyka-495426905578.asia-southeast1.run.app",
  installMethod: "startup_folder",
};

// GET /api/system/autostart
app.get("/api/system/autostart", (req, res) => {
  const currentUrl = `${req.protocol}://${req.get("host") || "localhost:3000"}`;
  res.json({
    config: {
      ...autoStartConfig,
      launchPath: currentUrl,
    },
    windowsStartupFolder: "%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup",
    registryKey: "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
    powershellCmd: `$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut("$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\BharatVani.lnk"); $Shortcut.TargetPath = "msedge.exe"; $Shortcut.Arguments = "--app=${currentUrl}"; $Shortcut.Save()`,
  });
});

// POST /api/system/autostart
app.post("/api/system/autostart", (req, res) => {
  const { enabled, startMinimizedToIcon, playGreetingOnBoot, installMethod } = req.body;
  if (typeof enabled === "boolean") autoStartConfig.enabled = enabled;
  if (typeof startMinimizedToIcon === "boolean") autoStartConfig.startMinimizedToIcon = startMinimizedToIcon;
  if (typeof playGreetingOnBoot === "boolean") autoStartConfig.playGreetingOnBoot = playGreetingOnBoot;
  if (installMethod) autoStartConfig.installMethod = installMethod;

  res.json({
    success: true,
    message: autoStartConfig.enabled
      ? "Auto-Start enabled for Windows boot."
      : "Auto-Start disabled.",
    config: autoStartConfig,
  });
});

// GET /api/system/autostart/script - Generate and download Windows Auto-Start batch file
app.get("/api/system/autostart/script", (req, res) => {
  const hostUrl = `${req.protocol}://${req.get("host") || "localhost:3000"}`;
  const minimizedParam = req.query.minimized === "true" ? "?mode=icon" : "";
  const finalUrl = `${hostUrl}/${minimizedParam}`;

  const scriptContent = `@echo off
:: ============================================================================
:: Bharat Vani - Windows Auto-Start Setup
:: Registers Bharat Vani AI Assistant to automatically start when PC turns on.
:: ============================================================================
echo [Bharat Vani] Setting up Windows Auto-Launch on System Boot...
echo Target URL: ${finalUrl}

set "STARTUP_FOLDER=%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
set "SHORTCUT_PATH=%STARTUP_FOLDER%\\BharatVani.lnk"

:: Create shortcut in Windows Startup directory using PowerShell
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Shortcut = $WshShell.CreateShortcut('%SHORTCUT_PATH%'); " ^
  "$Shortcut.TargetPath = 'msedge.exe'; " ^
  "$Shortcut.Arguments = '--app=${finalUrl} --enable-features=OverlayScrollbar'; " ^
  "$Shortcut.Description = 'Bharat Vani Windows AI Assistant'; " ^
  "$Shortcut.WindowStyle = 1; " ^
  "$Shortcut.Save(); " ^
  "Write-Host '[SUCCESS] Bharat Vani shortcut placed in Windows Startup folder!';"

:: Also add registry backup
reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "BharatVaniAssistant" /t REG_SZ /d "msedge.exe --app=${finalUrl}" /f >nul 2>&1

echo.
echo ============================================================================
echo  Bharat Vani is now configured to start automatically on Windows Boot!
echo  Location: %SHORTCUT_PATH%
echo ============================================================================
echo You can close this window now.
pause
`;

  res.setHeader("Content-Type", "application/x-bat");
  res.setHeader("Content-Disposition", 'attachment; filename="BharatVani_AutoStart_Setup.bat"');
  res.send(scriptContent);
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🇮🇳 Bharat Vani server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
